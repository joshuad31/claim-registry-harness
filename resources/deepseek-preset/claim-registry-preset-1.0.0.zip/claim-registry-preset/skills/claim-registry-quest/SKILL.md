---
name: claim-registry-quest
description: 'Runs the Claim Registry (ACH 2.0) `cr.py` pipeline on Windows: startup and personality, the `cr next` progress protocol, new/frame/chat-coach/doctor/quest/run, per-axis run databases, a background quest with STOP, and exact recovery commands. Use when coaching a Claim Registry investigation.'
---

# Claim Registry quest playbook

If they ask for the harness itself to be changed, stop and load `claim-registry-harness-dev`. Otherwise this is the research job.

## Locate, then start

- Harness = the folder with `cr.py` **and** `claimreg\checklist.py`, `claimreg\personality.py` and `agent\research-personality\PERSONALITY.md` (usually `claim-registry-harness` in the workspace); a glob only finds candidates — never run the older copies. Run every command from that folder (`workdir`), not the person's project folder.
- Windows PowerShell; quote every path: `python cr.py run "projects\MyTopic"`. Prefer `python cr.py` (`cr` needs `cr.cmd`); no `git`; Python 3.11+ (3.13 here).
- `python cr.py start` must be read in full. If truncated, run every numbered `python cr.py personality --part N` it lists. After context loss, `python cr.py personality` reloads it.
- Asked to launch/start/open: there is no program. First reply is "What do you want to research?" plus at most two sentences. Do not run tests or the demo, do not read the repo first.

## Where things stand

- `python cr.py next --json` (no folder before a project exists; then `python cr.py next "<project folder>" --json`). Use its `why`, `do`, `for_the_assistant`; never track progress yourself.
- `--md` prints the table; `--window` writes and opens `CHECKLIST.html`; `--watch` refreshes it (`--every <seconds>`).
- `python cr.py next "<project>" --done sources` and `... --done notebook` (undo `--undo`) record the person's own confirmations in `CHECKLIST.json`; run them only after they explicitly confirm, never on your own judgment.

## The path

1. `python cr.py new "<project>" --name "<topic>" --corpus "<folder of .md/.txt>" --keys "<folder of key .txt files>" --notebook "<link>"` → `project.json`, `01_FRAME\question.md`. Keys are found by file name; `--key provider=path` names one, `--prefer openai,deepseek,...` orders them; `--force` rewrites a project.
2. You write their answer into `question.md` under "What I want to decide" and "Who or what it is about", in their words; read it back and let them correct it. `cr frame` refuses while a `REPLACE` line remains, and every axis needs at least two hypotheses.
3. `python cr.py frame "<project>"` → `index.md`, `archivist-custom-prompt.txt`, `header-DRAFT.md`; offline drafts are rough. Clean project words out of the Archivist prompt if warned.
4. They review; you help with wording only. Coach in chat (next section), then accept only their exact reviewed wording. Do not use `cr approve` to bypass the coach.
5. `python cr.py doctor "<project>"` checks Python, Playwright, Chrome, corpus, header, index, notebook links and keys; fix any FAIL. `cr quest` also refuses without an approved header, an accepted coach session, a working notebook link and Playwright. `--fix`, `--offline`, `--models`, `--notebooks`.
6. They set NotebookLM: one notebook with all sources, Configure Chat -> Custom, paste `archivist-custom-prompt.txt`, Longer; 3-6 copies, each checked. Then record their `--done notebook` confirmation.
7. `python cr.py quest "<project>"` — next section.
8. `python cr.py run "<project>"` runs FRDs, validation, witnesses, units, matching, coverage, crux, report; resumable and cached; it halts after `frd_assess`: read `FRD-EVALUATION.md`, then continue with the printed `--continue` command.
9. PDFs: `python cr.py convert "<project>" --dry-run` first; details in `claim-registry-papers`.

## Coaching in chat (`docs/CHAT-COACH.md`)

`cr coach` (alias `cr sign`) is the chat flow; `--terminal` is legacy, never offer it.

- `python cr.py coach "<project>"` returns `step`, `revision`, `question`, `show` and instructions. Never show its JSON, IDs, revision numbers or numeric choices; ask one question in ordinary words, one explanation at a time.
- Record their actual reply in a response file built from the returned `next_request.base_payload` (it carries `session_id` and `revision`), add `text` copied from their words, then `--action reply --response-file "<file>"`. Every submission carries the returned `session_id` and current `revision`. Preference step: include `choice` (saved hypothesis ID or null); never ask for a code.
- `confirmed: true` only when their reply really confirms what was shown. `--action prepare` at `prepare`; `--model-review` is optional, costs usage, and its forecasts are advice, not results. `--action select` uses revision, reply and zero-based `choice`; `--action revise` needs `text` and a `candidate` (question plus every hypothesis); `--action restart` after file changes or to take an opening.
- Only at `step: approval` may you `--action accept` with `session_id`, revision, their actual reply and `confirmed: true`. Never `cr approve`, `--terminal`, or an invented reply. `cr sign --check` reports saved acceptance. Read the next step from the command, not memory.

## Long quest: background job plus STOP

- Start `python cr.py quest "<project>"` as a background shell job (up to 3 hours; do not block); it launches driver/relay, preflights lanes, imports the quest and prints its run id.
- Chrome stays open and unminimized. Watch `<project>\quest\<id>\relay-status.json` and `driver.log`.
- Stop: empty `STOP` file in `<project>\quest\<id>\`. Lanes finish, the Manager grades, the quest closes; rerun resumes (nothing graded twice).
- Lane down or wedged: never restart the relay. Restore the window, then restart only the driver: `python -m claimreg.notebooklm.driver run "<project>\quest\<id>\quest.json"`. Link typo: `cr doctor "<project>" --notebooks`.
- Needs a model key for quest Investigator/Manager, plus Playwright and Chrome; the Chrome sign-in is theirs.

## Folders and run databases

Project: `project.json`, `01_CORPUS\source-files` (only ingested), `01_CORPUS\pdf`, `01_CORPUS\manifests`, `01_FRAME`, `02_RUNS`, `04_RELEASES`, `90_METHOD\prompts`, `quest`, `queue`, `cache`, `SOURCES.md`, `CHECKLIST.json/.html`.

Each run `02_RUNS\<run>\` opens `RUN-MAP.md` first; each axis is `AXIS-A1__<label>\` holding `08_COVERAGE\` (`PREMISE-LEDGER.md`, `HYPOTHESIS-REQUIREMENTS.md`) and `10_REPORTS\` (`CRUX-REPORT.md`, `EVIDENCE-PACKETS.md`, `report.html`). No file holds two axes.

- `python cr.py status "<project>"`; `python cr.py funnel "<project>"` (one funnel per axis); `python cr.py verify "<project>"` (exit code 3 when not ok); `python cr.py questions "<project>"` writes `QUESTIONS.md`.

## Recovery

- Stage `error`: `python cr.py status "<project>"`; traceback in `<run>\00_RUN-CONTROL\stage-state.json`; fix, rerun.
- Stage `partial`: failed calls were not cached, so rerun asks them again. A prompt edited in `90_METHOD\prompts\` changes the cache key.
- One stale answer: delete `cache\llm\<first two characters>\<key>.json` (key in `<run>\00_RUN-CONTROL\model-and-human-decisions\llm-calls.jsonl`), then `cr run "<project>" --from <stage>`.
- Rejected queued answer: `queue\import-log.json` says why; fix it and `python cr.py queue import "<project>"`. Re-ask a skipped request: delete `queue\done\<key>.skip.json`.
- `cr quest` refuses: header missing or unapproved (`cr frame`, then their approval), no accepted coach session (run `cr coach` in chat and record their replies), bad link (`cr doctor --notebooks`), or no model key.
- Coach stop: `COACH-CHECKPOINT-1.md` (answers) or `COACH-CHECKPOINT-2.md` (findings). Moves: `python cr.py coach "<project>" --axis A2 --action restart`, review the new wording in chat, then `python cr.py rescore "<project>" --run <RUN>` (`--answers` at checkpoint 1); ask more; `cr run "<project>" --continue`. The checkpoint is authoritative, not your forecast.

## Variants, release, boundaries

- `python cr.py fork "<project>" --from <RUN> --name <NEW> --set witness.raw_ceiling=80 --note "..."`; `python cr.py diff "<project>" <RUN-A> <RUN-B>`; `python cr.py publish "<project>" --run <RUN> --include-corpus` → `04_RELEASES\RELEASE-...`.
- Never fabricate a reply or accept for them. Never state a result the files do not show; a forecast is not a result.
- About 150 words, one next step, one question; the person decides what they read; NotebookLM never learns the rival answers, the index or any score.
