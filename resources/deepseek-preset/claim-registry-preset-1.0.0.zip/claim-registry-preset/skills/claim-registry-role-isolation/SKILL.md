---
name: claim-registry-role-isolation
description: 'Keeps Claim Registry blind roles blind: fresh `subagent` contexts (never a fork) for the FRD validator, witness constructor/auditor and matching passes A/B, the quest Investigator/Manager split, and exact `cr queue import/skip` batch rules. Use before any blind role, queue or validation work.'
---

# Blind-role operating rules

The method works only if the roles that must not see something cannot see it. A leaked frame, score or peer judgment invalidates the work quietly, so treat separation as a hard requirement, not a style.

## The invariant

- Whoever writes the questions never sees the scores; whoever scores never touches NotebookLM; whoever validates a claim sees no question, hypothesis or index; matching pass A and pass B never see each other; the witness auditor never wrote the witness.
- Every blind role runs in its own fresh, single-use context. Size one context per role, finish it, abandon it.
- Use the preset's `subagent` tool with a complete, self-contained prompt. Every child starts under the separate minimal `claim-registry-worker` preset — no mentor persona, no startup instructions, no research memories — and that is the isolation boundary. Never `subagent_fork` (it inherits this conversation and its frame), never resume a finished context for a second role, and never play two blind roles in this conversation. The child cannot see this conversation, so the request must stand alone.

## What each role may see

| Role | Sees only | Must not see |
|---|---|---|
| `frd_validator` | One candidate FRD and the named source text | Question, hypothesis, index, other answers, outside knowledge |
| `witness_constructor` | The producing question, the validated FRD | Scores, other witnesses, matching results |
| `witness_auditor` | Producing question (context), parent FRD, the witness | Who wrote it, hypotheses, scores |
| `matcher_a` / `matcher_b` | One coverage unit and the witness list, plus the `HID`/`HYP_BRIEF` their prompt supplies for scope | The other pass, scores, adjudicator relations; the frame beyond that brief |
| `match_adjudicator` | The unit and the disputed pairs (both passes' relations) | A third relation neither pass gave |
| `quest_investigator` | Header, index, public packets, questions already asked | Manager private files, ledger, scores |
| `quest_manager` | Header, index, ACH_Eval spec, answers staged by the Investigator | NotebookLM, the browser, the Investigator's queue |

When spawning: paste the exact role brief if the request asks for one, then only the request text. Do not add the frame, the rival answers, the index, a score, or "for context" file contents beyond what the role's own prompt supplies. The child preset is deliberately blind: it has no mentor persona, research memories, AGENTS.md or startup instructions, so do not assume it knows anything you did not put in the request. `claimreg\prompts\frd_validate.md`, `witness_audit.md`, `match_a.md` and `match_b.md` state each role's own boundary; the queue's system prompt already carries it, so send the batch request verbatim.

## Answering the file queue

When a role is routed to `queue`, the run writes requests to `<project>\queue\pending\` and packs them in `<project>\queue\batches\`:

- `BATCH-0007-matcher_a.json` — `{"requests": [{"key", "role", "expect_json", "system", "user"}, ...]}`
- `BATCH-0007-matcher_a.md` — the same, for pasting into a chat window

Rules for whoever answers:

1. One request at a time and independently: answer exactly as a model given only that request's system and user text would. Nothing carries between requests.
2. No outside material: open no other file, search nothing, and do not use the rest of the batch as context for one answer.
3. Separate contexts per role; batches are grouped by role so this is mechanical.
4. When `expect_json` is true, the answer is one valid JSON value and nothing else.
5. Record who answered.

Save answers next to the batch as `BATCH-0007-matcher_a.response.json` — `{"<key>": "<answer>", ...}` (a JSON object is allowed as the answer) — or as `.response.md` with one `=== RESPONSE <key> ===` block per request. Then:

```
python cr.py queue import "<project>" --operator-model "<model or person>"
python cr.py run "<project>"
```

If a request cannot be answered, never invent one:

```
python cr.py queue skip "<project>" --key <key> --reason "why it was not answered"
python cr.py queue skip "<project>" --batch BATCH-0007-matcher_a --reason "..."
```

A blind worker has no shell: have it return the answers, write the `.response.json`/`.response.md` yourself, then run `python cr.py queue import "<project>" --operator-model "<model that answered>"`; never let the child record its own import.

The harness records the call as failed and says so downstream: a witness is held, a relation is missing. To ask again later, delete `queue\done\<key>.skip.json`. `python cr.py queue status "<project>"` shows what waits; `python cr.py queue export "<project>" --size 12 --role matcher_a` repacks pending work. A rejected response stays pending and `queue\import-log.json` says why, usually invalid JSON.

## The quest's two agents

- `cr quest` runs the relay, which already gives the Investigator and Manager roles separate model calls. When you are filling those roles by hand, keep two contexts: one reads `claimreg\notebooklm\INVESTIGATOR.md`, the other reads `claimreg\notebooklm\MANAGER.md`.
- Investigator: writes 6-12 questions per batch, each naming one to three exact source filenames and demanding a full answer. The 900-word floor is on the answer the question requires, not on the question's own length: never ask for a short or brief answer, and only a single-source question may state a length ("about 900 words or more"). No project vocabulary; queue them into the answers folder. Never read the Manager's `private\` folder, fragments, ledger or assessment inputs.
- Manager: grades every 5-6 answers with ACH_Eval, commits a round, writes the public packet with 8-10 ready questions. Never touch NotebookLM, a browser tab or the lanes. Public packets contain no allocation vectors, percentages, hypothesis labels or fragment text.
- NotebookLM (the Archivist) never learns the rival answers, the index, any score or what the person hopes to find. Never use "Discover sources"/Fast Research or import its results; never save answers to notes; upload sources only.
- `cr import-quest` deliberately leaves the Manager's private files out of the run; the run's own assessment is made fresh.

## Anti-patterns to refuse

- One context answering `matcher_a` then `matcher_b`, or the constructor then the auditor.
- Giving a queue answer "the bigger picture", the header, or a guess at the expected verdict.
- Showing the question-writer a score, a packet's vectors or the Manager's ledger.
- Telling NotebookLM the hypotheses, the index, the score or "what we are trying to prove".
- Running two blind roles with the same `subagent` name or the same conversation; a fresh context is part of the experiment.
