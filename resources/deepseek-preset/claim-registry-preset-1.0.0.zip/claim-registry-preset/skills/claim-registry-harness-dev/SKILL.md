---
name: claim-registry-harness-dev
description: 'Maintains the Claim Registry (ACH 2.0) harness: read HANDOFF.md then BUILD-RECORD, keep `claimreg/` stdlib-only and `prompts/spec/` unchanged, respect role-boundary invariants, run `selftest`/`demo`, update docs, work git-less on Windows. Use only when its code, tests, prompts or docs must change.'
---

# Harness maintainer job

This skill applies only when the person asks, in so many words, for the harness itself to be changed (its code, tests, prompts or documents). Anything else is the research job; load `claim-registry-quest` instead and do not run the tests or the demo.

## Read first, in this order

1. `HANDOFF.md` — written for whoever maintains this code next. Read §1-§8, then every dated update (§9 onward): they record what changed, what was fixed, what was deliberately declined and what is still open. §15-§19 matter most for boundaries.
2. `docs/BUILD-RECORD.md` — what each shipped run demonstrates, the honest limits, and the folder map.
3. `AGENTS.md`, `README.md`, `START HERE.md` — the product contract the code serves.
4. The relevant specification. The source documents live in the workspace folder that holds the harness (the numbered specification files 01-14 and 9a-9d). Their shipped copies under `claimreg/prompts/spec/` are used **verbatim** and must not be edited: `ACH_Eval_NLM_Super.md`, `Quest_Header_Generator_v2.md`, `Archivist_Prompt_Generator_v4.md`, `FRD_Generation_Template_v3.1.md`, `FRD_Validation_Template_v3.1.md`, `Superior_Mr_Fusion_4-ACH.md`, `Superior_Mr_Dictionary_v5.1.md`, `Mr_Canonicalizer_v1.1.md`, `Mr_Transcoder_v1.0.md`.
5. `docs/DECISIONS.md` and the dated `docs/DECISIONS-*.md` files — every place the spec was open and what was chosen. Record a new open-spec choice the same way.

## Invariants (do not break)

- `claimreg/` is standard-library only. Playwright is needed only by the NotebookLM driver; `requests` only by optional `cr convert`. Do not add a runtime dependency to the pipeline.
- Role boundaries: the FRD validator is blind (source text only); the witness auditor is independent of the constructor; matching pass A and B are independent, with adjudication labelled; the quest Investigator never sees scores and the Manager never touches NotebookLM. The interface already exposes `subagent` for fresh contexts — never collapse two blind roles into one context.
- The header is the only place a researcher may tilt a run, and only they approve it. Nothing downstream of the header may be tilted: no down-ranking, excluding or re-grading of sources, and no topic-specific rule set (`claimreg/domains/` was removed; do not add it back).
- No signatures, passphrases or tamper checks (removed 2026-11-14; see `docs/FRAME-GATE.md`, "What is not in the harness"). Do not reintroduce proof machinery without being asked. `cr coach`/`cr sign` default to the chat coaching flow (`claimreg/chat_coach.py`, `docs/CHAT-COACH.md`); `--terminal` is the legacy interview. The acceptance record is the person's actual chat replies, not a gate.
- The ACH_Eval prompt and the 64-unit gauge are unchanged. Code stays topic-neutral: nothing may know what a run is about.
- `cr.py` stays a thin launcher; the commands live in `claimreg/cli.py`. CLI and provider/role names are a user-facing contract — `claimreg/config.py` lists the roles. Keep commands resumable, cached, and honest about status (`waiting`, `halted`, `partial`, `error`).

## Test and verify

- `python cr.py selftest` — the whole suite, about two minutes, no network and no model calls.
- `python tests/test_notebooklm_driver.py` — the browser mock-notebook test, about 90 seconds, run directly.
- `python cr.py demo` — a complete offline run of the synthetic corpus. It writes a new project under `projects\` (`DEMO-2` if `DEMO` exists); use `--project "<dir>"` to choose, and know that `--force` REPLACES a non-empty folder — verify the path before using it.
- Add or extend a test for every fix, as the existing fixes do (`tests/test_review_fixes.py`, `tests/test_frame_gate.py`, `tests/test_checklist.py`, ...). Report what passed, and say plainly what was only reasoned about and not run. Never make a live model or paid call unless asked.
- For pipeline changes, also re-run the affected path on a fixture run and check `python cr.py verify "<project>"`; for report changes, read the written artifacts, do not assume.

## What to update with a change

- Code: `claimreg/` modules, `cr.py`/`cr.cmd`, `tests/`.
- Docs, when behaviour or wording changes: `README.md`, `docs/WALKTHROUGH.md`, `docs/USER-GUIDE.md`, `docs/NOTEBOOKLM-QUEST.md`, `docs/CHAT-COACH.md` (and `claimreg/chat_coach.py` for the assistant adapter), the relevant `docs/*.md`, and `docs/guide/*.md` for anything the person reads. Guide pages feed the checklist window: keep to headings, paragraphs, lists, bold, italic, code and links — no tables.
- `HANDOFF.md`: add a dated section saying what changed, how it was tested, what it does not fix, and what is open. This is the handover record.
- `docs/BUILD-RECORD.md`: update the claims about shipped runs only when a run was actually produced or re-run.
- `AGENTS.md`, `CLAUDE.md`, `GEMINI.md`, `START HERE.md`: startup protocol only; they are the host contract. `cr next` steps are product wording — do not add a step without a file-based test or an explicit confirmation it is `--done`.
- Personality files under `agent/research-personality/`: adding or editing one requires `python tools/package_research_kit.py` to refresh the distribution ZIP and the generated `.cursor/rules/*.mdc`. Do not hand-edit generated rules. Files on disk are authoritative.

## Environment and handoff

- Windows, PowerShell. Python 3.11+ (find it with `python`/`py` and note the version you find). Quote every path.
- **Check for `git` before relying on it.** If it is absent, the person probably publishes another way (for example GitHub Desktop): write the changed files into their clone, say what changed, and let them commit and push; push only with their OK.
- Share a plan of steps before a substantial piece of work, then work through it. Recognise "good enough": stop optimising when he says the work is done. Be adversarial about the evidence, never about the legitimacy of someone's research. Choose sensible output locations rather than asking.
- Work in the canonical harness folder (the four-marker rule in `AGENTS.md`; usually `claim-registry-harness\` in the workspace), keep the diff to what the job needs, and leave the person's research project untouched: never edit `projects\<their project>\` unless the job is explicitly about it.
