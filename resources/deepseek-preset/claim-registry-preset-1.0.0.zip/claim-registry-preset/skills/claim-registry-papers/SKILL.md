---
name: claim-registry-papers
description: 'Acquires, verifies and converts Claim Registry sources (PubMed, Europe PMC, Semantic Scholar, OpenAlex, Unpaywall, Crossref): identity checks, SOURCES.md statuses, corpus thresholds, and Datalab `cr convert` cost and key files. Use when acquiring or converting sources.'
---

# Source acquisition and conversion

Load before searching, downloading, verifying, filing or converting sources. Do the legwork; they decide what goes in.

## Corpus policy (advisory)

- Aim for at least 50 relevant, distinct sources. Five papers is one batch, not a stopping point.
- Below 20: say plainly that the recommended route is converting them to Markdown and uploading them directly to an LLM. At 20-49: say it is below the intended minimum and help acquire more, including contrary evidence.
- Explain once, then comply if the informed person still wants the smaller run. Record the choice; never add a gate or repeat the pressure.
- Never pad: duplicates, one paper counted as PDF and Markdown, abstracts, citations, metadata-only records and irrelevant files do not count. `cr next --json` gives a file-inventory estimate (`corpus_size.count`) that still needs identity and relevance review.

## Lawful routes

- Medicine: PubMed, Europe PMC and PubMed Central (full text, often open access).
- Search and index: Semantic Scholar, OpenAlex, DOAJ, CORE, OA.mg, ScienceOpen.
- DOI to a free copy: Unpaywall. Verify DOIs with Crossref (`api.crossref.org/works/<DOI>`) and PubMed.
- Preprints: arXiv, bioRxiv, medRxiv. Also publishers' open-access pages, university repositories, author pages or an email to the author (offer to draft it), libraries and interlibrary loan, government repositories, trial registries (ClinicalTrials.gov), regulatory documents (FDA labels, EMA reports), court databases.
- The person decides what they use; never tell them what they may read, and never lecture them about paywalls or Sci-Hub. Your own retrieval follows the repository's written policy (`AGENTS.md`): use the routes above and record what you cannot retrieve as a gap. `agent\research-personality\memory\` keeps old sci-hub links as retained history, not current instructions; their use is the person's own choice.
- Person-facing pages to offer: `docs\guide\getting-papers.md` and `docs\guide\sources.md`.

## Identity before download

- Check every identifier against title, first author, year and journal. Model-generated DOIs are often wrong (a bad suffix, another paper, an invented version). Correct and tell them what you corrected; never silently rewrite their list.
- Check what they already own and flag duplicates; one paper under a DOI-style name and an authorYear name is one source. Some papers have no DOI: give the free journal page or a paste-ready search string, not a store or borrow page.
- An abstract is not the paper. If only an abstract exists, keep it but label it, and say the answers will be thinner.

## Download, name, file

- Free copy -> `<project>\01_CORPUS\pdf\firstauthorYEAR.pdf` (for example `shirazi2024.pdf`). Only `01_CORPUS\source-files` is ingested; `pdf\` is the inbox for conversion.
- Hash or UUID file names: establish identity, then rename the PDF and its converted `.md` to authorYear form, keeping a collision map. Never rename known sources halfway through a frozen run.
- Preserve originals. Copy each finished file into their folder as it completes; keep completed work if their machine drops.
- After a batch: PDF count equals Markdown count, none empty or mismatched. Check hard tables, numbers, units and symbols against the original; file counts and accurate mode do not prove fidelity.

## When you cannot download

Say exactly why and the way round; report what you tried and what came back. Never guess.

- publisher sells it, no free copy: library or institution, an email to the author (offer to draft it), interlibrary loan;
- free to read but blocks automated download: give them the link, and they save the PDF;
- needs their sign-in: they sign in; you never handle a password;
- your environment has no internet or blocks downloads: say so and give links;
- only an abstract, or the paper cannot be identified: say so.

A paper you cannot get is a recorded gap.

## `SOURCES.md`

Keep `<project>\SOURCES.md`: one row per paper with the reason it matters, the link, and one status:

- `downloaded` — file in place, identity checked (note `identity OK` or `verified`);
- `waiting for them` — you gave the link; they save it;
- `gap` — the exact reason and the way round.

Group by acquisition round and list open gaps last. It stays outside `source-files`.

## Convert with `cr convert`

- Preview: `python cr.py convert "<project>" --dry-run` lists files with no upload and no key.
- Run: `python cr.py convert "<project>" --mode accurate` reads `01_CORPUS\pdf` by default (`--folder` overrides), writes `<source>.pdf.md` into the project's corpus folder (`01_CORPUS\source-files`), and keeps state in `.conversion-state`. `--workers 3` (1-8); `--force` reconverts and can charge again; `--mode balanced|fast` only when they are in a hurry.
- It uploads to Datalab and costs money: explain that before first use. Never print or paste a key; pass `--key-file "<path>"` or let it read `DATALAB_API_KEY`. It needs `requests` (`pip install requests`).
- Conversion appends `.md` only. No provenance headers (NotebookLM rejects them) and no pdftotext for evidence. Pending jobs resume without resubmitting; report converted, skipped, existing-unverified and failed. Nothing is ingested automatically: review, then `python cr.py corpus "<project>"` or `cr new --force`.
- Bibliographies and search notes stay Markdown planning artifacts outside the corpus (title, authors, year, journal/volume/pages, DOI, PMID, abstract). `SOURCES.md`, manifests, PDFs and fetch notes never enter `source-files`.

## What leaves their computer

Tell them once, when it first applies: searches go to the sites searched; PDFs to the converter chosen; sources to NotebookLM when uploaded; passages to the models that score them.
