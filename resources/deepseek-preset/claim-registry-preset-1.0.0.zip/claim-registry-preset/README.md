# Claim Registry — DeepSeek Harness agent preset (shareable copy)

An agent preset that turns a DeepSeek Harness session into the Claim Registry (ACH 2.0) research coach: the host assistant described by the `claim-registry-harness` repository's `AGENTS.md`.

It carries the repository's launch protocol, its state machine (`python cr.py next`), its source and evidence rules, its role-isolation boundaries, and four operating skills that keep a long investigation on the rails — with the tools that protocol actually needs.

> The preset is not the harness. It never writes into the repository; it only runs the harness the way the repository tells an assistant to.

## What you need first

1. The **harness repository** (the folder holding `cr.py`, `claimreg/checklist.py`, `claimreg/personality.py`, `agent/research-personality/PERSONALITY.md`, plus `AGENTS.md` and `docs/`). Its files are the authority; if this preset and the repository disagree, the repository wins.
2. **Python 3.11 or newer** on `PATH`. Nothing else is installed for you.
3. A DeepSeek Harness desktop install.

## Install

1. Put this folder somewhere stable (a linked install reads it in place, so do not delete or move it afterwards).
2. In a **normal DSH session** — not a Claim Registry coach session, which deliberately has no `plugin_manager` tool — ask the assistant to install the bundle at this folder's absolute path:

   `plugin_manager` → `install_bundle` → `<absolute path to this folder>`

3. Open a **new** session, choose the **Claim Registry** preset, and set the workspace to your harness repository folder.

## Using it

- **Workspace:** open the session on the harness repository folder. That is how `AGENTS.md` auto-loads and how the coach finds the current build. If the workspace is a parent folder, the coach locates the build by its four files, but the repository instructions will not auto-load.
- **Permissions:** the preset does not pick a permission mode. For real work use **Full access**, or approve per call: the harness writes into your project folder, which may sit outside the session workspace, and it downloads papers. A read-only session can still coach, but cannot run the pipeline.
- **Start by asking for it:** "I want to use Claim Registry." The first reply is *"What do you want to research?"* A research question is what the whole run is aimed at.

## Two presets — do not pick the worker

The bundle declares the coach preset you select (`claim-registry`) and an internal worker preset (`claim-registry-worker`). Every `subagent` child the coach starts runs under the worker preset: a minimal persona with only read/write/edit, no mentor persona, no `AGENTS.md`, no research memories, no web, skills, shell or nested agents. That is what keeps the blinded roles (FRD validator, matching passes, witness audit, queue batches) from seeing the frame, the preferred answer or scores. Do not select the worker preset yourself; it exists only for those children.

## Keep the package name

`package.json` names the bundle `@local/dsh-claim-registry-preset`, and the persona's skill mount resolves `skills/` through that name (`cordis.patch.yml`, the `skill-filesystem` row). If you rename the package, update that `!!js` expression to match.

## What is deliberately left out

- **No `subagent_fork`.** Forked children inherit the parent conversation, which would leak hypotheses and scores into a blind role. Only fresh `subagent` spawns are mounted, and every one is pinned to the internal `claim-registry-worker` preset.
- **No `tool-result-pruner`.** It would trim the middle of the large `cr.py start` result in later requests — exactly the standing personality the repository requires.
- **No `tool-plugin-manager`.** A coaching session should not reconfigure its own profile. Install, update or remove this bundle from a normal session.

## Updating

The `skills/` folder is a snapshot of the repository's four skill bundles. When the repository's protocol or skills change, refresh this copy and reinstall: `plugin_manager` → `remove_bundle` → `install_bundle` (a linked bundle cannot be installed over itself). Existing sessions keep the composition they started with; new sessions get the edit.

To uninstall: `plugin_manager` → `remove_bundle` → `@local/dsh-claim-registry-preset`.

## What was generalised in this copy

This bundle came from a working install on the maintainer's machine. Three kinds of machine-specific wording were rewritten so it works anywhere:

- The persona's description of where the harness lives and where older `cr.py` builds may sit (no folder names from the original workspace).
- The harness-development skill's mentions of the original specification folder, the original Python patch version, a missing `git`, GitHub Desktop as the only publishing route, and the original workspace folder name.
- The quest skill's parenthetical workspace folder name.

Everything else is unchanged from the verified install — including the two-preset blind-worker isolation, the corrected `--done` confirmation rule and the clarified answer-length rule.

## Verifying the bundle

The bundle is `package.json` + `cordis.patch.yml` + `skills/`. A static check of the same structure used by the maintainer can be pointed at this folder:

```text
python verify/validate_preset.py --bundle <this folder>
```

(That checker lives with the maintainer's install, not in this copy.) The same check is run on the folder and on the extracted ZIP before release.
